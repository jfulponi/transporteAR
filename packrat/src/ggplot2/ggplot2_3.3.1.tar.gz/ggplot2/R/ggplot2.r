#' @keywords internal
"_PACKAGE"

#' @import scales grid gtable rlang
#' @importFrom stats setNames
#' @importFrom glue glue glue_collapse
NULL
